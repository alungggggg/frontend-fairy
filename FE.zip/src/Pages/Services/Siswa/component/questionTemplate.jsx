const QuestionTemplate = ({ soal, pilihanGanda }) => {
    const pilihan = ['a', 'b', 'c', 'd']
    return (
        <div>

        </div>
    )
}

export default QuestionTemplate